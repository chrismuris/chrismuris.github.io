#' ##############################
#' ## Some auxiliary functions ##
#' ##############################
#' 
#' Functions for data generation, estimation, and optimal averaging.
#' 
#' - IPWnLogit		computes IPWn estimate and deriv and var matrix.
#' - IPWnFIC		computes FIC for model based on model spec "S", 
#' 				estimate of deriv matrix, estimate of var matrix,\
#'                              estimated ddhat				
#' - getWeights.Bayes	computes weights for BayesLE based on dhat, Dhat, Sigmahat
#' - getWeights.HC	computes weights for HC  based on dhat, Dhat, Sigmahat
#' - settoform  	from an "S" vector of includable covariates, generates formula
#' - genData 		generates data
#' 
#' ------------------------------------

IPWnFIC <- function(S,M.NPW,V.NPW,ddhat) {
  
  #' Returns the value of the FIC criterion for a given submodel S
  #' given estimates of the derivative matrix, the variance matrix,
  #' and the estimated ddhat.
  
  #' There computations here follow directly the derivations 
  #'   in (3.1)-(3.4) on p. 16 of the manuscript (date Feb 5, 2015)
  #' 
  #' K regressors, so with a constant we have K+1 effective regressors.
  #' 

  #' First, edit "S" so that it includes a constant.
  Sconst = c(1,S+1)
  #' Construct the selection matrix pi...
  piS <- diag(K+1)[Sconst,]
  nS <- length(Sconst)
  #' ...  and the associated Lambda matrix, which picks the right 
  #'    moment conditions from m.
  #' This means that from the first 1:(K+1), we select those in S.
  #' Also select the last two (they are the non-ML ones)
  LambdaS <- matrix(0,nrow=nS+2,ncol=(K+3))
  LambdaS[1:nS,1:(K+1)] <- piS
  LambdaS[nS+1,K+2] <- 1
  LambdaS[nS+2,K+3] <- 1

  #' For the bias expression, we also need Lambda for S_complement.
  #' Construction is similar as before, but for 1:(K+1) \ S
  S_C <- setdiff(1:(K+1),Sconst)
  nS_C <- length(S_C)
  #' Now repeat steps from above
  
  piS_C <- diag(K+1)[S_C,]
  if(nS_C==0) {
    piS_C <- matrix(0,nrow=1,ncol=(K+1))
  }

  #' ...  and the associated Lambda matrix, which picks the right 
  #'    moment conditions from m.
  LambdaS_C <- matrix(0,nrow=nS_C+2,ncol=(K+3))
  
  if(nS_C>0) {
    # "if" because replacement term would have NULL dimension
    LambdaS_C[1:nS_C,1:(K+1)] <- piS_C  
  }
  
  LambdaS_C[nS_C+1,K+2] <- 1
  LambdaS_C[nS_C+2,K+3] <- 1

  #' Then we can get the matrices in (3.1) and (3.2)
  MS <- LambdaS %*% M.NPW %*% t(LambdaS)
  invMS <- solve(MS)
  VS <- LambdaS %*% V.NPW %*% t(LambdaS)
  
  #' ... and then the LHS of (3.1) ...
  omega2S.pre <- invMS %*% VS %*% t(invMS)
  omega2S <- omega2S.pre[nS+2,nS+2]
  
  #' For the bias term, (LHS's of (3.2))
  #'  we need to do a bit more work.
  bS_pre <- invMS %*% (LambdaS %*% M.NPW %*% t(LambdaS_C))
  bS <- bS_pre[nS+2,1:nS_C]
  
  #' Then we obtain dds, which is the one right before (3.4)
  #' This is simply selecting the non-S (=omitted) entries of ddhat.
  #' Then obtain the bias^2 using (3.4)
  ddS <- 0
  bias2.S <- 0
  if(nS_C>0) {
    ddS <- ddhat[S_C,S_C]
    bias2.S <- max(t(bS) %*% ddS %*% bS,0)
  }
  
  #' This yields the FIC for model S.
  FICS <- bias2.S + omega2S
  
  #' Also return: row for the B matrix! (described at top of page 19,
  #'    features in (3.7) and in the asymptotic MSE in (3.8) 
  #'    through K)
  #'    
  BS <- matrix(bS,nrow=1) %*% piS_C
  
  #' Also return: row the T matrix 
  #'    This matrix is used for construction of Omega,
  #'  ... which is used to compute optimal weights.
  TS <- (- invMS %*% LambdaS)[nS+2,]
  
  output <-        list( ddS,  omega2S,    FICS ,  bS,   TS,  BS,    bias2.S)
  names(output) <- c(   "ddS", "varS",    "FICS", "bS", "TS", "BS", "bias2.S" )
  return(output)
}

getWeights.Bayes <- function(Sigma,Bmat,dhat,reg) {
  
  #' Computes the weights for the proposed averaging estimator
  K <- ncol(Bmat)-1
  nsubmodels <- nrow(Bmat)
  
  # Obtain matrix partition
  Sigma11 <- Sigma[1:(K+1),1:(K+1)]
  Sigma22 <- Sigma[(K+2):nrow(Sigma),(K+2):nrow(Sigma)]
  Sigma12 <- Sigma[(1):(K+1),(K+2):nrow(Sigma)]
  Sigma21 <- t(Sigma12)

  # One step further to obtain ingredients.
  invSigma11 <- solve(Sigma11)
  M <- Bmat - Sigma21 %*% invSigma11
  Kpost <- Sigma22 -
    Sigma21 %*% invSigma11 %*% Sigma12 +
    M %*% Sigma11 %*% t(M) +
    Bmat %*% dhat %*% t(dhat) %*% t(Bmat)
  #' Regularized inverse, "reg" in [0,1], higher means more regularization
  iK <- solve(reg*diag(diag(Kpost %*% Kpost)) + Kpost %*% Kpost) %*% Kpost
  
  # Weights
  wts <- iK %*% (numeric(nsubmodels)+1)
  cstar.Bayes <- wts / sum(wts)  
  
}

getWeights.HC <- function(Sigma,Bmat,dhat) {
  
  K <- ncol(Bmat)-1
  nsubmodels <- nrow(Bmat)
  
  # Obtain matrix partition
  Sigma11 <- Sigma[1:(K+1),1:(K+1)]
  Sigma22 <- Sigma[(K+2):nrow(Sigma),(K+2):nrow(Sigma)]
  Sigma12 <- Sigma[(1):(K+1),(K+2):nrow(Sigma)]
  Sigma21 <- t(Sigma12)
  
  # One step further to obtain ingredients.
  invSigma11 <- solve(Sigma11)
  M <- Sigma22 + Bmat %*% (dhat %*% t(dhat) - invSigma11) %*% t(Bmat)
  # Weights
  wts <- ginv(M) %*% (numeric(nsubmodels)+1)
  cstar.HC <- wts / sum(wts)  
  
}

IPWnLogit <- function(df,RHS1,retDV=TRUE) {
  #' Implements IPW estimator for ATT,
  #'     with normalized weights and a logit function wrapped around
  #'     "RHS1".
  #' 
  #' Output:
  #'   - "tauhatIPWn" contains the estimate of the ATT   
  #'   - "alphahat" contains parameter estimate for normalizing
  #'             parameter in the MM formulation of the normalized weights.
  #'   - "gammahat" contains regression coefficient estimate for
  #'        P(D=1|X) = logit(X'gamma)
  #'   - "Em" sample mean of the moment functions
  #'   - "M" realization of the consistent estimator of deriv matrix
  #'   - "V" realization of consistent estimator of var matrix
  #'
  #' Input:
  #'   - "df" a data frame containing treatment indicator "D",
  #'          outcome variable "Y", and confounder "Xj" 
  #'          that appear in "RHS1"
  #'   - "RHS1" a formulate naming the confounders
  #'   - "retDV" indicator saying whether estimates of derivative
  #'              and variance matrix should be returned.
  
  
  #' 1.
  #' Run logit with variables in RHS1
  psreg <- glm(update.formula(RHS1, D ~ .), family = "binomial",data=df,x=TRUE)
  gammahat <- psreg$coefficients
  
  #' 2. 
  #' Extract model quantities at parameter estimate for 
  #'    estimation of D and V
  #' 
  XS <- psreg$x
  K <- ncol(XS)
  n <- nrow(XS)
  Xgam <- XS %*% gammahat
  GXgam <- exp(Xgam)/(1+exp(Xgam))
  gXgam <- GXgam*(1-GXgam) #assuming a logit, g = G(1-G)
  
  #' 3.
  #' Normalize the weights
  weight <- (1-df$D)*GXgam/(1-GXgam)
  nweight <- weight/sum(weight)
  tauhatIPWn <- sum(df$D*df$Y)/sum(df$D) - sum(nweight*df$Y)
  
  #' 4.
  #' Estimating alpha!
  weight.term <- df$D + (1-df$D)*(GXgam/(1-GXgam))
  alphahat <- sum(weight.term * (df$Y-tauhatIPWn*df$D)) / sum(weight.term)
  
  #' 5. 
  #' Initialize the optional returns.
  m <- matrix(numeric(9),ncol=3) #mysterious because arbitrary
  M <- 0
  V <- 0
  
  if(retDV) {
    
    #' If the user requests the variance and derivative matrices of
    #'   the moment functions for the largest model, we compute them here.
    #'   
    #' In the context of the model selection/averaging procedure in the paper,
    #'   this is useful because we only need these from the full model est.
    #'
    #' Expressions for these matrices can be found in the proof of Proposition 2.1
    #'   andin the Web Appendix Part I of Busso, Dinardi, and McCrary (REStat)
    
    #' First, compute the sample moments.    
    m1 <- matrix(as.vector(df$D-GXgam),nrow=n,ncol=K) * XS  #assuming a logit, g / (G(1-G)) = 1
    m2 <- weight.term*(df$Y-tauhatIPWn*df$D-alphahat)
    m3 <- weight.term*(df$Y-tauhatIPWn*df$D-alphahat)*df$D
    
    Q <- mean(df$D)
    KGXgam <- matrix(rep(GXgam,K),ncol=K)
    M11 <- -t(KGXgam*(1-KGXgam)*XS) %*% XS * (1/n)
    # Note that dm3/dgamma = 0,
    # and dm2/dgamma = (1-D)(Y-tauhat*D-alphahat) d(G/(1-G))/dgamma
    # also, d (G/(1-G)) / dgamma = G + G^2/(1-G) *X
    M21 <- colMeans(matrix(rep(GXgam+GXgam^2/(1-GXgam)*(1-df$D)*(df$Y-tauhatIPWn*df$D-alphahat),K),ncol=K)*XS)
    
    ## Construct the full derivative matrix
    M <- matrix(numeric((K+2)^2),ncol=(K+2))
    M[1:K,1:K] <- M11
    M[K+1,1:K] <- M21
    M[K+1,K+1] <- -2*Q
    M[K+1,K+2] <- -Q
    M[K+2,K+1] <- -Q
    M[K+2,K+2] <- -Q
    
    ## Now the variance matrix.
    V <- var(cbind(m1,m2,m3))
    ## Top left block follows from MLE, same as -Deriv.
    V[1:K,1:K] <- -M11
    # Impose the restriction that bottom right element equals 
    #   its neighbours to the north and west
    S.11 <- 1/2*(V[K+2,K+2]+V[K+1,K+2])
    V[K+2,K+2] <- S.11
    V[K+1,K+2] <- S.11
    V[K+2,K+1] <- S.11
    
  }
  
  output <- list(tauhatIPWn,       alphahat,  gammahat, colMeans(m),M,   V)
  names(output) <- c("tauhatIPWn","alphahat","gammahat","Em",      "M", "V")
  return(output)
  
}

genData <- function(muX,varX,gamma,beta0,beta1,sdY0,sdY1,nobs) {
  #'
  #' Generates the observable (Y,D,X) and also the unobservables (Y0,Y1)
  #'    for a cross-section program evaluation setting with a logit
  #'    selection rule and linear outcomes.
  #' 
  #' Input
  #'  "muX" and variance "varX" describe the 
  #'           distribution of the multivariate X
  #'  "gamma": P(D=1|X) = logit(X'gamma)
  #'  "beta0": Yi(0) = X_i beta0 + ui(0)
  #'  "beta1": Yi(1) = X_i beta1 + ui(1)
  #'  "sdY0" and "sdY1": standard devs of ui(1) and ui(0)
  #'  "nobs" is the number of observations in the data frame.
  #'  
  #'  Output  
  #'   "data.frame(Y,Y0,Y1,D,X)"
  
  # Nomber of variables.
  K <- length(muX)
  
  #X is from a multivariate normal distribution with mean muX and variance varX
  # This returns a nobs x K matrix of observations on the covariates.
  X <- mvrnorm(n = nobs, mu=muX, Sigma=varX, tol = 1e-6, empirical = FALSE)
  
  #Simulate the latent variable model for D, and obtain D
  Xp <- cbind(1,X) %*% gamma
  probLog <- exp(Xp)/(1+exp(Xp))
  D <- rbinom(nobs,1,probLog)
  
  #eD <- rnorm(nobs,mean=0,sd=1)
  #Dstar <- gamma0 + gamma1*X1 + gamma2*X2 + eD
  #D <- Dstar*0
  #D <- replace(D,Dstar>0,1)
  
  u0 <- rnorm(nobs,mean=0,sd=sdY0)
  Y0 <- cbind(1,X)%*%beta0 + u0
  
  u1 <- rnorm(nobs,mean=0,sd=sdY1)
  Y1 <- cbind(1,X)%*%beta1 + u1  
  
  Y  <- D*Y1 + (1-D)*Y0
  
  df <- data.frame(Y,Y0,Y1,D,X)
  return(df)
}

get.models <- function(modelSet) {

  #Initialize the list
  subModels <- list(seq(1,K));
  
  if(modelSet == 1) {
    useAll <- TRUE
    # Get set of submodels.
    nAllSubmodels <- 2^K - 1;
    subCount <- 0
    for(i in seq(1,nAllSubmodels)) {
      # Trick to loop over all possible submodels, including the full model.
      expons <- 2^(0:(K-1))
      S <- which( (i %% (2*expons))>=expons  )
      if((1 %in% S) || useAll) { # Select only those that include
        subCount <- subCount + 1
        subModels[[subCount]] <- S
      }
    }
    nsubmodels <- subCount
    
  }
  
  if(modelSet == 2) {
    useAll <- FALSE
    # Get set of submodels.
    nAllSubmodels <- 2^K - 1;
    subCount <- 0
    for(i in seq(1,nAllSubmodels)) {
      # Trick to loop over all possible submodels, including the full model.
      expons <- 2^(0:(K-1))
      S <- which( (i %% (2*expons))>=expons  )
      if((1 %in% S) || useAll) { # Select only those that include
        subCount <- subCount + 1
        subModels[[subCount]] <- S
      }
    }
    nsubmodels <- subCount
    
  }
  
  if(modelSet ==3) {
    # Number of submodels is equal to K
    nsubmodels <- K
    # Construct the set
    for(k in 1:nsubmodels) {
      subModels[[k]] <- 1:k
    }
  }
  
  if(modelSet ==4) {
    # Only biggest and smallest model
    nsubmodels <- 2
    # Construct the set
    subModels[[1]] <- 1
    subModels[[2]] <- 1:K
  }
  
  output <- list(nsubmodels,subModels)
  names(output) <- c("nsubmodels","subModels")
  
  return(output)
}



settoform <- function(S) {
  #' Accepts S, a vector of numbers
  #' Returns a formula: 
  #'
  #'  Example: S = (1,3,4)
  #'  Returns a formula object   ~ 1 + X1 + X3 + X4
  #'  
  
  fstr <- "~ 1"
  for(i in S) {fstr <- paste(fstr,"+X",sep=)
               fstr <- paste(fstr,i,sep="")}
  formret <- as.formula(fstr)
}

