###################################
##
## Master file
##   Implements simulation studies in Kitagawa & Muris (2015)
##   This script calls auxiliary functions and runs NReps
##   Monte Carlo instances for a given design.
##
## Last edited: 2015, July 18
###################################


########################
#### 1: Initializiation
########################
# Clear the workspace
rm(list = ls())

# Loading packages, auxiliary functions
require(doMC)
require(MASS)
source("20150219_auxfunc.R")
source("20150315_insideLoop.R")

# Set up parallel stuff
spare <- 0
registerDoMC(detectCores()-spare)

#################################################
### 2: Set simulation design parameter values ###
#################################################

# Number of repetitions in the Monte Carlo
NReps <- 20000
# Sample size
n <- 100
# Number of regressors
K <- 3

# Which models do we consider?
# 1: All 2^K models
# 2: All 2^(K-1) models that include X1
# 3: All K models that can include X(j) only if they include X(j-1)
# 4: Consider only the big and the small model
modelSet <- 2
use.models <- get.models(modelSet)
nsubmodels <- use.models$nsubmodels
subModels <- use.models$subModels

# Relative importance of X1 vs Xk, k>1
imp.X1 <- 0.5

# Variance of the outcome equation error terms
sdY0 <- 2
sdY1 <- 2

# Setting up coefficients in the outcome equation
# Tweaking the bias due to left out regressors
base.coefs <- c(0,imp.X1,rep((1-imp.X1)/(K-1),K-1))
# Y1 = X beta_1 + u_1
beta1 <- 0*base.coefs
# Y0 = X beta_0 + u_0
b.scale        <- 1 
beta0 <- -b.scale*base.coefs

# Distribution of X
muX <- numeric(K)
varX.par <- 0.5
varX <- varX.par*diag(K) + (1-varX.par)*(numeric(K)+1)%*%t(numeric(K)+1)

index <- 0
results.c <- list()
for(c.scale in seq(from=0,to=2,by=0.1)) {
  # In this loop, we are varying the degree of misspecification
  index <- index + 1
  print(c.scale)
  
  # Selection equation coefficients
  gamma <- c.scale*c(0,rep(1/K,K))
  
  ######################
  ### SIMULATE TAU_0 ###
  ######################
  # Desired number of observations.
  ntrue <- 1e7
  # Generate 10 such samples,
  #   - print them to see the range
  #   - take their average as a simulated approximation of tau.0
  tau.true.sum <- 0
  for(tries in 1:10) {
    df <- genData(muX,varX,gamma,beta0,beta1,sdY0,sdY1,ntrue)
    tau.true <- sum(df$D*(df$Y1-df$Y0))/sum(df$D)
    print(sprintf("True tau %d: %4f",tries,tau.true))
    rm(df)
    tau.true.sum <- tau.true.sum + tau.true
  }
  tau.true <- tau.true.sum/tries
  
  #################
  # MONTE CARLO ###
  #################

  # Reproducability
  set.seed(2015)
  
  # use doMC!
  results <- foreach (i=1:NReps, .combine=rbind) %dopar%  {
  
      res.s <- one.iteration(muX,varX,gamma,beta0,beta1,sdY0,sdY1,n,K,nsubmodels,fname,tau.true)
      c(n,K,c.scale,tau.true,res.s[[1]],res.s[[2]],
                 res.s[[3]],res.s[[4]],
                 res.s[[5]],res.s[[6]],
                 res.s[[7]])
  }

  results <- as.data.frame(results)
  colnames(results) <- c("n","K","gamma","tau.true",
                                "tau.hat.small","tau.hat.big",
                                "tau.hat.Bayes","tau.hat.HC",
                                "tau.hat.minMSE","tau.hat.ivec",
                                "tau.hat.Bayes.nest")
  results.c[[index]] <- results
  
} #closes gamma for loop

# Save, and plot
save(results.c, file = "results.RData")
source("20150620-pubishablePlots.R")

