August 12, 2015
---------------

Disclaimer: 

This folder contains the code that we use to run our simulation studies.
Adapting it to your application may not be straightforward. However,
feel free to contact the authors, who will be happy to help out if you get
stuck with this code.

---------------


This folder contains the code for the simulations in 

	"Model averaging in semiparametric estimation of treatment effects"

by Toru Kitagawa and Chris Muris. When run, it generates the top-left
panels of Figures 1 and 2.

Run "20130515_main.R" while R's working directory is equal to the directory
containing the four R files listed below.

To generate the other panels in Figures 1 and 2, manipulate the
parameter values in "20130515_main.R".

To apply

Index:

"20130515_main.R"
	Main file. Calls all the other files. Computes tau0 by approximation.
	   Run this to generate Figures 1 and 2. 
           Contains shell code for simulations. Allows you to tweak
               simulation design.

"20150315_insideLoop.R"
	Executes one simulation. This file is called within the MC for-loop
           in the main file.

	To apply our estimator to your data, collect your data in a data frame,
	   call the dependent variable "Y", call the explanatory variables "X1",
           "X2", ..., "X6", call the treatment indicator "D", and run parts 2
           through 4 in this file.

"20150219_auxfunc.R".
	Contains a number of auxiliary functions, including data generation,
        computation of optimal weights.
        
"20150620-pubishablePlots.R"
        Generates pdf figures that we include in the paper.
