rm(list=ls())
require(plyr)
require(ggplot2)
load("results.RData")

## Generate results by value of gamma
mean.results <- ldply(results.c,colMeans)
var.results  <- ldply(results.c,function(x) { diag(var(x))})
names(mean.results) <- c("n","K","gamma","tau.true",
                         "E.tau.hat.small","E.tau.hat.big",
                         "E.tau.hat.Bayes","E.tau.hat.HC",
                         "E.tau.hat.minMSE","E.tau.hat.ivec",
                         "E.tau.hat.Bayes.nest")
var.results <- subset(var.results,select=5:11)
names(var.results) <- c("V.tau.hat.small","V.tau.hat.big",
                        "V.tau.hat.Bayes","V.tau.hat.HC",
                        "V.tau.hat.minMSE","V.tau.hat.ivec",
                        "V.tau.hat.Bayes.nest")

sim.results <- cbind(mean.results,var.results)

# Get the bias
sim.results$b.tau.hat.big <- sim.results$E.tau.hat.big - sim.results$tau.true
sim.results$b.tau.hat.small <- sim.results$E.tau.hat.small - sim.results$tau.true
sim.results$b.tau.hat.Bayes <- sim.results$E.tau.hat.Bayes - sim.results$tau.true
sim.results$b.tau.hat.Bayes.nest <- sim.results$E.tau.hat.Bayes.nest - sim.results$tau.true

# Get the rmse
sim.results$rmse.tau.hat.big <- sqrt(sim.results$b.tau.hat.big*sim.results$b.tau.hat.big+sim.results$V.tau.hat.big)
sim.results$rmse.tau.hat.small <- sqrt(sim.results$b.tau.hat.small*sim.results$b.tau.hat.small+sim.results$V.tau.hat.small)
sim.results$rmse.tau.hat.Bayes <- sqrt(sim.results$b.tau.hat.Bayes*sim.results$b.tau.hat.Bayes+sim.results$V.tau.hat.Bayes)
sim.results$rmse.tau.hat.Bayes.nest <- sqrt(sim.results$b.tau.hat.Bayes.nest*sim.results$b.tau.hat.Bayes.nest+sim.results$V.tau.hat.Bayes.nest)

# Compute the rmse relative to that of the full model
sim.results$rrmse.tau.hat.small <- sim.results$rmse.tau.hat.small / sim.results$rmse.tau.hat.big
sim.results$rrmse.tau.hat.Bayes <- sim.results$rmse.tau.hat.Bayes / sim.results$rmse.tau.hat.big
sim.results$rrmse.tau.hat.Bayes.nest <- sim.results$rmse.tau.hat.Bayes.nest / sim.results$rmse.tau.hat.big

# Generate bias plot
require(ggplot2)
p <- qplot(gamma,E.tau.hat.small,data=sim.results,colour=I("white")) + 
  stat_smooth(aes(x=gamma,y=E.tau.hat.small),linetype="dotted" ,se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=E.tau.hat.big),  linetype="dashed" ,se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=E.tau.hat.Bayes),linetype="twodash",se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=tau.true),       linetype="solid"  ,se=FALSE,colour="black")

#Generate RRMSE plot
q <- qplot(gamma,rmse.tau.hat.small,data=sim.results,colour=I("white")) + 
  stat_smooth(aes(x=gamma,y=rmse.tau.hat.big),linetype="dashed",se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rmse.tau.hat.small),linetype="dotted" ,se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rmse.tau.hat.Bayes),linetype="twodash",se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rmse.tau.hat.Bayes.nest),linetype="F1",se=FALSE,colour="black")

q.rel <- qplot(gamma,rrmse.tau.hat.small,data=sim.results,colour=I("white")) + 
  stat_smooth(aes(x=gamma,y=rrmse.tau.hat.small),linetype="dotted" ,se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rrmse.tau.hat.Bayes),linetype="twodash",se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rrmse.tau.hat.Bayes.nest),linetype="F1",se=FALSE,colour="black") + 
  geom_hline(yintercept = 1,linetype="dashed")

## Tweak and save bias plot

p <- p + labs(x = expression(gamma), y = expression(paste(tau[0],", ","E(",hat(tau),")")))  +
  #scale_linetype_manual(name="",
  #                      values = c("dotted","dashed","solid"),
  #                      labels = c("solid"="Full model",
  #                                 "dashed"="GMM 1",
  #                                 "dotted"="GMM 2")) +
  theme_bw(base_size = 18) +                
  theme(axis.title.x = element_text(hjust=0.5,vjust=0.5),
        axis.title.y = element_text(hjust=0.5,vjust=0.5)) +
  xlim(0,2)

p <- p + annotate("text",x=1.3,y=0.4,label = "True value")
p <- p + annotate("text",x=1.8,y=0.34,label = "Full model")
p <- p + annotate("text",x=1.73,y=0.25,label = "BayesLE (All)")
p <- p + annotate("text",x=1.75,y=0.11,label = "Small model")

p
ggsave("sim-Bias.pdf",width=6,height=6)

# # Tweak and save the RMSE plot
# q <- q + labs(x = expression(gamma), y = "RMSE")  +
#   theme_bw(base_size = 18) +                
#   theme(axis.title.x = element_text(hjust=0.5,vjust=0.5),
#         axis.title.y = element_text(hjust=0.5,vjust=0.5))
# q
# 
# ggsave("sim-RMSE.pdf",width=6,height=6)
# 
# q.rel <- q.rel + labs(x = expression(gamma), y = "relative RMSE")  +
#   theme_bw(base_size = 18) +                
#   theme(axis.title.x = element_text(hjust=0.5,vjust=0.5),
#         axis.title.y = element_text(hjust=0.5,vjust=0.5))
# q.rel
# 
# ggsave("sim-RRMSE.pdf",width=6,height=6)
# 


#######################
## Adding the MSE (not RMSE) plots

# Document the MSE
sim.results$mse.tau.hat.big <- sim.results$b.tau.hat.big*sim.results$b.tau.hat.big+sim.results$V.tau.hat.big
sim.results$mse.tau.hat.small <- sim.results$b.tau.hat.small*sim.results$b.tau.hat.small+sim.results$V.tau.hat.small
sim.results$mse.tau.hat.Bayes <- sim.results$b.tau.hat.Bayes*sim.results$b.tau.hat.Bayes+sim.results$V.tau.hat.Bayes
sim.results$mse.tau.hat.Bayes.nest <- sim.results$b.tau.hat.Bayes.nest*sim.results$b.tau.hat.Bayes.nest+sim.results$V.tau.hat.Bayes.nest

# Compute the MSE relative to that of the full model
sim.results$rel.mse.tau.hat.small <- sim.results$mse.tau.hat.small / sim.results$mse.tau.hat.big
sim.results$rel.mse.tau.hat.Bayes <- sim.results$mse.tau.hat.Bayes / sim.results$mse.tau.hat.big
sim.results$rel.mse.tau.hat.Bayes.nest <- sim.results$mse.tau.hat.Bayes.nest / sim.results$mse.tau.hat.big

q.rel.MSE <- qplot(gamma,rel.mse.tau.hat.small,data=sim.results,colour=I("white")) + 
  stat_smooth(aes(x=gamma,y=rel.mse.tau.hat.small),linetype="dotted" ,se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rel.mse.tau.hat.Bayes),linetype="twodash",se=FALSE,colour="black") + 
  stat_smooth(aes(x=gamma,y=rel.mse.tau.hat.Bayes.nest),linetype="F1",se=FALSE,colour="black") + 
  geom_hline(yintercept = 1,linetype="dashed")

q.rel.MSE <- q.rel.MSE + labs(x = expression(gamma), y = "relative MSE")  +
  theme_bw(base_size = 18) +                
  theme(axis.title.x = element_text(hjust=0.5,vjust=0.5),
        axis.title.y = element_text(hjust=0.5,vjust=0.5)) +
  scale_x_continuous(expand=c(0,0)) + scale_y_continuous(limits=c(0.73,1.06),expand=c(0,0))

q.rel.MSE
  
ggsave("sim-rel-MSE.pdf",width=6,height=6)

  
