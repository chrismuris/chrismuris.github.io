one.iteration <- function(muX,varX,gamma,beta0,beta1,sdY0,sdY1,n,K,nsubmodels,fname,tau.true) {
  
  #' This is the main function.
  #'    
  #' Inputs:
  #' 
  #'    (muX,...,K) - inputs for DGP. See "genData" in "auxfunc.R"
  #'    nsubmodels - How many submodel estimators to consider. 
  #'    fname - output will be directed here
  #'    tau.true - (simulated) true value of the parameter of interest ATT
  #'    
  #' Output:
  #'    none! they are written to a textfile so that we can
  #'          keep track of results during long simulation runs.
  #'          
  #' Structure
  #' 
  #'    1. Data is generated.
  #'    2. Estimate full model
  #'    3. Estimate all submodels,  
  #'    3b. Get bias and variances for all estimators
  #'    4. Obtain compromise estimators
  #'    4a. Bayes
  #'    4b. HC
  #'    4c. Min-FIC, and weighted FIC
  #'    5. Write output
  
  ####################
  # 1. Generate data
  ####################
  df <- genData(muX,varX,gamma,beta0,beta1,sdY0,sdY1,n)
  # Sample ATT for full sample
  tau.SATT <- sum(df$D*(df$Y1-df$Y0))/sum(df$D)
  
  ####################
  # 2. Estimate full model
  ####################
  
  ### FULL MODEL QUANTITIES
  # Select all variables.
  S <- seq(1,K); RHS1 <- settoform(S)
  # Get the full model estimation results
  resIPWn <- IPWnLogit(df,RHS1,retDV=TRUE)
  tau.full <- resIPWn$tauhatIPWn #full model tau-hat
  V.NPW <- resIPWn$V # full model variance est
  M.NPW <- resIPWn$M # full-model deriv est
  invM.NPW <- solve(M.NPW) # ... and its inverse.
  # dhat and ddhat,
  dhat <- sqrt(n)*resIPWn$gammahat
  # information matrix of ML estimation
  # The inverse of this is the asymptotic variance of gamma-hat
  I.gamma <- V.NPW[1:(K+1),1:(K+1)] # = E[hh']
  I.gamma.inv <- solve(I.gamma)
  ddhat <- dhat %*% t(dhat) - I.gamma.inv
  
  ##############################
  # 3. SUBSET ESTIMATORS
  ##############################
  # tau.vec stores the submodel estimators for this Monte Carlo full-sample
  tau.vec <- numeric(nsubmodels)
  # Initialize B.mat, which keeps track of vectors b.S.NPW
  B.mat <- matrix(numeric(nsubmodels*(K+1)),nrow=nsubmodels)
  # Similar for T
  T.mat <- matrix(numeric(nsubmodels*(K+3)),nrow=nsubmodels)
  
  # Initialize some vectors: formula, tau
  formula.vec <- tau.vec <- numeric(nsubmodels)
  
  # Analytical bias/variance/FIC will be stored here
  varhat.vec <- bias2hat.vec <- FIChat.vec <- numeric(nsubmodels)
  
  ### LOOP 2A: SUBMODEL LOOP  
  for(i in seq(1,nsubmodels)) {
    # Loop over submodels, and put in formula form.
    S <- subModels[[i]]
    RHS1 <- settoform(S)
    formula.vec[i] <- as.character(RHS1)[2]
    
    # Get the results
    subRes <- IPWnLogit(df,RHS1,retDV=TRUE)
    tau.vec[i]<- subRes$tauhatIPWn
    
    ####################################
    # 3b. Obtain VARIANCES/BIAS/FIC
    ####################################
    # Function "IPWnFIC" returns all ingredients
    FICcomps   <- IPWnFIC(S,M.NPW,V.NPW,ddhat)

    # Extract main ingredients: bias-squared, variance, and MSE
    bias2hat.vec[i] <- FICcomps$bias2.S
    varhat.vec[i]   <- FICcomps$varS
    FIChat.vec[i]   <- FICcomps$FICS
    
    # For optimal weighting, we also need the appropriate rows
    #   for the B and T matrices. These are also returned
    #   by IPWnFIC. 
    B.mat[i,] <- FICcomps$BS
    T.mat[i,] <- FICcomps$TS

  } #end of submodel loop.
  
  ####################
  # 4. Obtain compromise estimators
  ####################
  
  # Get the variance according to analytical expressions.
  # This involves the matrices Ehh.inv, T, and V.
  # big.Pre is such that Omega = Var(big.Pre %*% m_i)
  big.Pre <- matrix(numeric((K+1+nsubmodels)*(K+3)),nrow=(K+1+nsubmodels))
  big.Pre[1:(K+1),1:(K+1)] <- M.NPW[1:(K+1),1:(K+1)]
  big.Pre[(K+2):(K+1+nsubmodels),] <- T.mat
  Sigma.A <- big.Pre %*% V.NPW %*% t(big.Pre)
  
  #########################
  # 4a. OPTIMAL BAYES ESTIMATOR
  # The following gives the weights, and then estimates
  cstar.Bayes.A <-  getWeights.Bayes(Sigma.A,B.mat,dhat,0.1)
  tau.Bayes.A <-  sum(cstar.Bayes.A * tau.vec)
  
  # For nested models only.
  tau.Bayes.A.nest   <-  0
  if(modelSet==2) {
    
    # If we consider all 2^(K-1)-1 submodels,
    #  let's also get the optimal estimator based on the K nested models.
    
    # Figure out which models out of the full model set are selected.
    nested <- lapply(subModels,function(x){prod(diff(x))==1})
    nest.model.index <- which(unlist(nested))
    nest.index.2 <- K+1 + nest.model.index
    nest.index.1 <- 1:(K+1)
    nest.index   <- c(nest.index.1,nest.index.2)
    
    # Select the appropriate variance matrix
    Sigma.A.nest <- Sigma.A[nest.index,nest.index]
    B.mat.nest   <- B.mat[nest.model.index,]
    
    # Get the estimate.
    tau.vec.nest <- tau.vec[nest.model.index]
    cstar.Bayes.A.nest <-  getWeights.Bayes(Sigma.A.nest,B.mat.nest,dhat,0.1)
    tau.Bayes.A.nest   <-  sum(cstar.Bayes.A.nest * tau.vec.nest)
     
  }
  
  
  #########################
  # 4b. HJORT AND CLAESKENS
  #########################
  cstar.HC.A <-  getWeights.HC(Sigma.A,B.mat,dhat)
  tau.HC.A <-  sum(cstar.HC.A * tau.vec)
  
  ############
  # 4c.Some simple alternative compromise estimators.
  
  #' Pick the model with lowest FIC  
  MSE.A.index <- which(FIChat.vec==min(FIChat.vec))
  tau.minMSE.A <- tau.vec[MSE.A.index]
  
  #' Assign each submodel estimator a weight ...
  #'  ... that is inversely proportional to its FIC.
  #'  This corresponds to full regularization.
  wts <- 1/FIChat.vec / sum(1/FIChat.vec)
  tau.ivecMSE.A <- sum(wts*tau.vec)
  

  # returning the output
  list.out <- list(tau.vec[1],tau.vec[nsubmodels],
                   tau.Bayes.A,tau.HC.A,tau.minMSE.A,tau.ivecMSE.A,tau.Bayes.A.nest)
  names(list.out) <- c("tau.hat.small","tau.hat.big",
                       "tau.hat.Bayes","tau.hat.HC",
                       "tau.hat.minMSE","tau.hat.ivec",
                       "tau.hat.Bayes.nest")

  return(list.out)
  
}
