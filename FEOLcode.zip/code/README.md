# README for computer programs for "Estimation in the fixed effects ordered logit model" by Chris Muris

Comments and questions are welcome at cmuris@sfu.ca.

## Empirical illustration

To replicate the empirical illustration in Section 7, Table 2, take the following steps:
1. Obtain the MEPS panel 16 data from http://meps.ahrq.gov/data_stats/download_data_files_detail.jsp?cboPufNumber=HC-156
2. Using Stata, run the do-file "h156stu.txt", which can be found in the data set downloaded under 1. Running that do-file creates a Stata data file called "H156.dta".
3. Place the "H156.dta" file you created in Step 2 in the same folder as the do-file "Muris-FEOL-Illustration.do" in this archive.
4. Run "Muris-FEOL-Illustration.do". See the comments in that file for more details.

I provide the resulting output in a log file named "Muris-FEOL-Illustration.log".

## Simulations

To replicate the Monte Carlo results in Tables 3, 4, 5, and 6 in Section B of the Supplementary Material, you can run the respective do-files in this archive. I have provided the expected out in log files.

For example, to replicate the results in Table 5, simply use Stata to run the file "Muris-FEOL-Table5.do". The expected out is in the log-file "Muris-FEOL-Table5.log".
